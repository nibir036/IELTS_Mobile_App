import 'package:flutter/material.dart';

import '../../app/data/demo.dart';
import '../../app/data/store.dart';
import '../../app/nav.dart';
import '../../app/routes.dart';
import '../../app/theme/tokens.dart';
import '../../app/widgets/app_icons.dart';
import '../../app/widgets/kit.dart';
import 'widgets.dart';

/// Category tag tints from the canvas (same in Day and Night).
Color _categoryTint(String category) {
  switch (category) {
    case 'Places':
      return const Color(0xFFDCDDFA);
    case 'Objects':
      return const Color(0xFFF7EDC4);
    case 'Events':
      return const Color(0xFFEEEFFD);
    case 'Experiences':
      return const Color(0xFFDCDDFA);
    case 'Media':
      return const Color(0xFFF7EDC4);
    default:
      return const Color(0xFFF9D6E2);
  }
}

/// D8 · Cue card practice vault. Bookmarks live in kv ([kSavedCardsKey]);
/// "You: 6.5" badges come from the student's Part 2 attempts.
class CueCardVaultScreen extends StatefulWidget {
  const CueCardVaultScreen({super.key});

  @override
  State<CueCardVaultScreen> createState() => _CueCardVaultScreenState();
}

class _CueCardVaultScreenState extends State<CueCardVaultScreen> {
  late final Map<String, dynamic> _vault = speakingData().m('vault');
  late final List<Map<String, dynamic>> _all = allCueCards();
  int _category = 0;
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final t = context.tk;
    // All · Saved · the six bank topics.
    final categories = <String>['All', 'Saved', ...kCueTopics];
    final selectedCategory =
        _category < categories.length ? categories[_category] : 'All';
    final store = context.store;
    final saved = store.kvSet(kSavedCardsKey);
    final youBands = <String, double?>{};
    final practised = <String>{};
    for (final a in store.attemptsFor(skill: Skill.speaking, kind: 'part2')) {
      if (practised.add(a.refId)) youBands[a.refId] = a.band;
    }
    final q = _query.trim().toLowerCase();
    final cards = _all.where((c) {
      final bool catOk;
      if (selectedCategory == 'All') {
        catOk = true;
      } else if (selectedCategory == 'Saved') {
        catOk = saved.contains(c.s('id'));
      } else {
        catOk = c.s('category') == selectedCategory;
      }
      final qOk = q.isEmpty ||
          c.s('title').toLowerCase().contains(q) ||
          c.s('category').toLowerCase().contains(q) ||
          c.ls('bullets').any((b) => b.toLowerCase().contains(q));
      return catOk && qOk;
    }).toList();
    // "Up next": the first card not practised yet, shown first as the
    // featured card when browsing everything.
    String featuredId = '';
    if (selectedCategory == 'All' && q.isEmpty) {
      for (final c in _all) {
        if (!practised.contains(c.s('id'))) {
          featuredId = c.s('id');
          break;
        }
      }
      if (featuredId.isNotEmpty) {
        final i = cards.indexWhere((c) => c.s('id') == featuredId);
        if (i > 0) cards.insert(0, cards.removeAt(i));
      }
    }
    final subtitle = _vault
        .s('subtitle')
        .replaceAll('{n}', '${_all.length}')
        .replaceAll('{practised}', '${_all.where((c) => practised.contains(c.s('id'))).length}');

    return AppScreen(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      gap: 14,
      children: [
        Row(
          children: [
            IconBox(
              icon: AppIcons.back,
              iconSize: 20,
              bg: t.surface,
              tooltip: 'Back',
              onTap: () => context.back(),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: t.surface,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(_vault.s('setLabel'), style: const TextStyle(fontSize: 13)),
            ),
          ],
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          spacing: 4,
          children: [
            const Text(
              'Cue card vault',
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w500,
                letterSpacing: -0.6,
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(fontSize: 14, color: t.textMuted),
            ),
          ],
        ),
        Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: t.surface,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            spacing: 10,
            children: [
              Icon(AppIcons.search, size: 18, color: t.textMuted),
              Expanded(
                child: TextField(
                  onChanged: (v) => setState(() => _query = v),
                  cursorColor: t.primary,
                  style: TextStyle(fontSize: 15, color: t.text),
                  decoration: InputDecoration(
                    isDense: true,
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                    hintText: 'Search a topic',
                    hintStyle: TextStyle(fontSize: 15, color: t.textMuted),
                  ),
                ),
              ),
            ],
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            spacing: 6,
            children: [
              for (var i = 0; i < categories.length; i++)
                FlatChip(
                  label: categories[i],
                  selected: i == _category,
                  bg: i == _category ? t.primary : t.surface,
                  fg: i == _category ? t.onPrimary : t.text,
                  onTap: () => setState(() => _category = i),
                ),
            ],
          ),
        ),
        if (cards.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: Text(
              selectedCategory == 'Saved' && q.isEmpty
                  ? 'No saved cue cards yet. Tap the bookmark on a card to keep it here.'
                  : 'No topics match your search.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: t.textMuted),
            ),
          ),
        Column(
          spacing: 10,
          children: [
            for (final c in cards)
              _VaultCard(
                card: c,
                featured: c.s('id') == featuredId,
                saved: saved.contains(c.s('id')),
                practised: practised.contains(c.s('id')),
                youBand: youBands[c.s('id')],
                onToggleSave: () => Store.I.kvSetToggle(kSavedCardsKey, c.s('id')),
                onTap: () => context.push(Routes.cueCard, args: {'cardId': c.s('id')}),
              ),
          ],
        ),
      ],
    );
  }
}

class _VaultCard extends StatelessWidget {
  const _VaultCard({
    required this.card,
    required this.featured,
    required this.saved,
    required this.practised,
    required this.youBand,
    required this.onToggleSave,
    required this.onTap,
  });

  final Map<String, dynamic> card;
  final bool featured;
  final bool saved;
  final bool practised;
  final double? youBand;
  final VoidCallback onToggleSave;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tk;
    final category = card.s('category');
    final tag = featured ? '$category · Up next' : category;
    final you = youBand;
    final youText = you != null
        ? 'You: ${bandText(you)}'
        : (practised ? 'Practised' : 'Not tried');

    final Color titleColor = featured ? t.heroText : t.text;
    final Color metaColor = featured ? t.heroMuted : t.textMuted;
    final Color tagBg = featured
        ? (t.isNight ? const Color(0x14151515) : const Color(0xCCFFFFFF))
        : _categoryTint(category);
    final Color tagFg = featured
        ? (t.isNight ? t.heroMuted : t.heroText)
        : (t.isNight ? const Color(0xFF625C66) : t.text);

    final content = Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        spacing: 10,
        children: [
          Row(
            children: [
              Expanded(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: tagBg,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      tag,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 12, color: tagFg),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: onToggleSave,
                child: Padding(
                  padding: const EdgeInsets.all(2),
                  child: Icon(
                    saved ? AppIcons.bookmarkFilled : AppIcons.bookmark,
                    size: 20,
                    color: titleColor,
                  ),
                ),
              ),
            ],
          ),
          Text(
            card.s('title'),
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              height: 1.25,
              color: titleColor,
            ),
          ),
          Wrap(
            spacing: 14,
            runSpacing: 4,
            children: [
              Text(
                'Card ${card.i('number')} · ${card.ls('part3').length} Part 3 Qs',
                style: TextStyle(fontSize: 12, color: metaColor),
              ),
              Text(youText, style: TextStyle(fontSize: 12, color: metaColor)),
            ],
          ),
        ],
      ),
    );

    if (featured) {
      return HeroCard(
        radius: 24,
        padding: EdgeInsets.zero,
        onTap: onTap,
        gradient: t.isNight
            ? null
            : const LinearGradient(
                begin: Alignment(-0.5, -0.87),
                end: Alignment(0.5, 0.87),
                colors: [Color(0xFFF7C6D6), Color(0xFFFCEBF1)],
              ),
        child: content,
      );
    }
    return AppCard(
      radius: 24,
      padding: EdgeInsets.zero,
      onTap: onTap,
      child: content,
    );
  }
}
